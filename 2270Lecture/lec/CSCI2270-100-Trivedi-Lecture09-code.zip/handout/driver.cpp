#include<iostream>
#include "listclass.hpp"

int main() {
  LinkedList llist;
  
  llist.insertNode(0, 22);
  llist.insertNode(22, 23);
  llist.insertNode(23, 55);
  llist.insertNode(55, 77);

  llist.traverse();

  llist.deleteNode(55);
  llist.traverse();

  llist.deleteNode(55);
  llist.traverse();

  
  return 0;
}
