struct Node {
  int data;         /* Data field */
  Node *next;       /* Next pointer */
};

