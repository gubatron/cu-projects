#include<iostream>
#include "listclass.hpp"

/**Function********************************************************************
   
   Synopsis      [The list constructor function.]
   
   Description   [Initializes the head and tail pointers.]
   
   Precondition  []

   Postcondition []

   SideEffects   [None.]
   
   SeeAlso       []
   
******************************************************************************/
LinkedList::LinkedList() {
  head = 0;
  tail = 0;
}

/**Function********************************************************************
   
   Synopsis      [The list destructor function.]
   
   Description   [Frees the memory occupied by the list.]
   
   Precondition  []

   Postcondition []

   SideEffects   [List memory is freed and list is no longer accessible.]
   
   SeeAlso       []
   
******************************************************************************/
LinkedList::~LinkedList() {
  Node *curr;
  Node *next;

  curr = next = head;

  while (curr != 0) {
    next = curr-> next;
    delete curr;
    curr = next;
  }
}

/**Function********************************************************************
   
   Synopsis      [The "traverse" function]
   
   Description   [Print the list.]
   
   Precondition  []

   Postcondition []

   SideEffects   [None.]
   
   SeeAlso       []
   
******************************************************************************/
void LinkedList::traverse() {
  Node* curr = head;

  std::cout<<"head->";
  while (curr != 0) {
    std::cout << curr->data << "->";
    curr = curr->next;
  }
  std::cout<<"tail" << std::endl;
}

/**Function********************************************************************
   
   Synopsis      [The "search" function]
   
   Description   [Returns a pointer to the first node with the data equal 
   to <val>.]
   
   Precondition  [<val> is of valid data values for the list.]

   Postcondition [Return value is equal to the pointer to the first node whose 
   data matched value, and is equal to 0 if there is no such node.]

   SideEffects   [None.]
   
   SeeAlso       []
   
******************************************************************************/
Node* LinkedList::search(int val) {
  Node* curr = head;
  
  while (curr != 0) {
    if (curr->data == val) return curr;
    curr = curr->next;
  }

  return 0;
}


/**Function********************************************************************
   
   Synopsis      [The "insertNode" function]
   
   Description   [Insert a new node into the linked list after the node with 
   a key value of leftValue.]
   
   Precondition  [<leftValue> and <value> are valid data values for the list.]

   Postcondition [The new ndoe has been added to the list after the node with 
   data equal to <ledtValue>.]

   SideEffects   [Adds a node in the list.]
   
   SeeAlso       [deleteNode]
   
******************************************************************************/
void LinkedList::insertNode(int leftValue, int value) {
  Node* left = search(leftValue);
  Node* node = new Node(value);
  
  if (left == 0) { /* inserting a new head node */
    node->next = head;
    head = node;
    if (tail == 0) tail = head;
  }
  else if (left->next == 0) { /* inserting a new tail node */
    left->next = node;
    tail = node;
    if (head == 0) head = node;
  }
  else { /* inserting a node in the middle */
    node->next = left->next;
    left->next = node;
  }
}

/**Function********************************************************************
   
   Synopsis      [The "deleteNode" function]
   
   Description   [Deletes the first node in the lsit with the specified value.
   If the value is not in the list, lsit remains unchanged. ]
   
   Precondition  [<value> is a valid data value for the list.]

   Postcondition [The first node matching the value has been removed from the 
   list. All other values keep their relative positions.]

   SideEffects   [Deletes a node from the list.]
   
   SeeAlso       [insertNode]
   
******************************************************************************/
void LinkedList::deleteNode(int value) {

  if (head->data == value) {
    Node* temp = head;
    head = head->next;
    delete temp;
  }
  else { /*either tail node or middle node */
    Node* left = head;
    Node* temp = left->next;
    bool isFound = false;
    while (temp != 0 && isFound != true) {
      if (temp->data == value) {
	if (temp->next == 0) { /* tail node */
	  left->next = 0;
	  tail = left;
	}
	else {
	  left->next = temp->next;
	}
	delete temp;
	isFound = true;
      }
      else {
	left = temp;
	temp = temp-> next;
      }
    }
  }
}

