#include <iostream>
using namespace std; 

int main() 
{
    cout << "Hello World! Hello CSCi 1300" << endl;
}
